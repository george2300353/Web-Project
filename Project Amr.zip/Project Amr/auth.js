// Modal functionality
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('authModal');
    const userIcon = document.getElementById('userIcon');
    const closeBtn = document.querySelector('.close-btn');
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    // Open modal when user icon is clicked
    userIcon.addEventListener('click', function() {
        modal.style.display = 'block';
    });

    // Close modal
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Tab switching
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Update active tab button
            tabButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Update active tab content
            tabContents.forEach(content => {
                content.classList.remove('active');
                if (content.id === tabId) {
                    content.classList.add('active');
                }
            });
        });
    });

    // Login form submission
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            const userRole = document.querySelector('input[name="userRole"]:checked').value;
            
            // Here you would typically send this data to your backend
            console.log('Login attempt:', { email, password, userRole });
            
            // For demo purposes, we'll just redirect
            if (userRole === 'admin') {
                window.location.href = 'admin.html';
            } else {
                // Redirect to user dashboard or home page
                window.location.href = 'home.html';
            }
            
            modal.style.display = 'none';
        });
    }

    // Register form submission
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('registerName').value;
            const email = document.getElementById('registerEmail').value;
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('registerConfirmPassword').value;
            
            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            // Here you would typically send this data to your backend
            console.log('Registration attempt:', { name, email, password });
            
            // For demo purposes, we'll just switch to login tab
            document.querySelector('.tab-btn[data-tab="login"]').click();
            document.getElementById('loginEmail').value = email;
            document.getElementById('loginPassword').value = password;
        });
    }
});