// Toggle login menu
document.getElementById('userIcon').addEventListener('click', function() {
    var menu = document.getElementById('loginMenu');
    if (menu.style.display === 'none' || menu.style.display === '') {
        menu.style.display = 'block';
    } else {
        menu.style.display = 'none';
    }
});

// Handle login form submission
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Example: Check if username and password are correct
    if (username === "user" && password === "password") {
        alert("Login successful!");
        // Redirect to another page or perform other actions
    } else {
        alert("Invalid username or password.");
    }
});

// Toggle login menu
document.getElementById('userIcon').addEventListener('click', function() {
    var menu = document.getElementById('loginMenu');
    if (menu.style.display === 'none' || menu.style.display === '') {
        menu.style.display = 'block';
    } else {
        menu.style.display = 'none';
    }
});

// Handle login form submission
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Example: Check if username and password are correct
    if (username === "user" && password === "password") {
        alert("Login successful!");
        // Redirect to another page or perform other actions
    } else {
        alert("Invalid username or password.");
    }
});
// Class details data
// Class details data - updated with all categories
const classDetails = {
    yoga: {
        title: "Yoga",
        image: "yoga-class.jpg",
        description: "Our yoga classes are designed to help you relax, stretch, and strengthen your body. Suitable for all levels, from beginners to advanced practitioners.",
        coach: "Emily Smith",
        schedule: "Monday, Wednesday, Friday at 7:00 AM and 6:00 PM"
    },
    pilates: {
        title: "Pilates",
        image: "pilates-class.jpg",
        description: "Pilates focuses on core strength, flexibility, and overall body awareness. Suitable for all fitness levels.",
        coach: "Sarah Lee",
        schedule: "Tuesday, Thursday at 9:00 AM and 6:00 PM"
    },
    hiit: {
        title: "HIIT",
        image: "hiit-class.jpg",
        description: "High-intensity interval training (HIIT) is perfect for burning fat and improving cardiovascular health. Each session is 45 minutes of intense, calorie-burning workouts.",
        coach: "John Doe",
        schedule: "Tuesday, Thursday at 7:00 AM and 5:00 PM"
    },
    cycling: {
        title: "Cycling",
        image: "cycling-class.jpg",
        description: "Cardio workout on stationary bikes. Great for improving endurance and burning calories.",
        coach: "Chris Brown",
        schedule: "Monday, Wednesday, Friday at 6:00 AM and 5:00 PM"
    },
    strength: {
        title: "Strength Training",
        image: "strength-class.jpg",
        description: "Build muscle and increase strength with our expert-led strength training sessions. We focus on proper form and technique to maximize results.",
        coach: "Mike Johnson",
        schedule: "Monday, Wednesday, Friday at 8:00 AM and 7:00 PM"
    },
    boxing: {
        title: "Boxing",
        image: "boxing-class.jpg",
        description: "Improve agility, strength, and endurance with our boxing classes. No prior experience required.",
        coach: "Alex Green",
        schedule: "Tuesday, Thursday at 8:00 AM and 7:00 PM"
    }
};

// Open modal with class details
function openClassModal(className) {
    const modal = document.getElementById("classModal");
    const details = classDetails[className];

    document.getElementById("modalTitle").textContent = details.title;
    document.getElementById("modalImage").src = details.image;
    document.getElementById("modalDescription").textContent = details.description;
    document.getElementById("modalCoach").textContent = details.coach;
    document.getElementById("modalSchedule").textContent = details.schedule;

    modal.style.display = "block";
}

// user icon menu
document.addEventListener('DOMContentLoaded', function() {
    // Get elements
    const userIcon = document.getElementById('userIcon');
    const authModal = document.getElementById('authModal');
    const closeBtn = document.querySelector('.close-btn');
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    // Open modal when user icon is clicked
    userIcon.addEventListener('click', function() {
        authModal.style.display = 'flex';
        // Reset to login tab when opening
        switchTab('login');
    });

    // Close modal when X is clicked
    closeBtn.addEventListener('click', function() {
        authModal.style.display = 'none';
    });

    // Close modal when clicking outside the modal content
    authModal.addEventListener('click', function(e) {
        if (e.target === authModal) {
            authModal.style.display = 'none';
        }
    });

    // Tab switching functionality
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            switchTab(tabId);
        });
    });

    function switchTab(tabId) {
        // Update active tab button
        tabButtons.forEach(button => {
            if (button.getAttribute('data-tab') === tabId) {
                button.classList.add('active');
            } else {
                button.classList.remove('active');
            }
        });

        // Update active tab content
        tabContents.forEach(content => {
            if (content.id === tabId) {
                content.classList.add('active');
            } else {
                content.classList.remove('active');
            }
        });
    }

    // Form submission handlers
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        
        // Here you would typically send this data to your server
        console.log('Login attempt with:', { email, password });
        
        // For demo purposes, just show an alert
        alert('Login functionality would be implemented here');
    });

    registerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('registerConfirmPassword').value;
        
        if (password !== confirmPassword) {
            alert('Passwords do not match!');
            return;
        }
        
        // Here you would typically send this data to your server
        console.log('Registration attempt with:', { name, email, password });
        
        // For demo purposes, just show an alert
        alert('Registration functionality would be implemented here');
    });
});


    const form = document.getElementById('paymentForm');
    const confirmation = document.getElementById('confirmation');
    const emailInput = document.getElementById('email');
    const planInput = document.getElementById('plan');

    const receiptEmail = document.getElementById('receiptEmail');
    const receiptPlan = document.getElementById('receiptPlan');
    const receiptDate = document.getElementById('receiptDate');

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      const currentDate = new Date().toLocaleDateString();

      receiptEmail.textContent = emailInput.value;
      receiptPlan.textContent = planInput.value;
      receiptDate.textContent = currentDate;

      form.classList.add('hidden');
      confirmation.classList.remove('hidden');
    });

    

    // admin.js - MVMNT Admin Dashboard Functionality

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard with dynamic data
    initDashboard();
    
    // Set up event listeners for sidebar navigation
    setupSidebarNavigation();
    
    // Simulate real-time data updates
    setInterval(updateStats, 5000);
});

function initDashboard() {
    // Initialize with current data
    updateStats();
    
    // Set up the current date in the hero section
    const today = new Date();
    document.querySelector('.admin-hero p').textContent += ` - ${today.toLocaleDateString()}`;
}

function updateStats() {
    // These would normally come from an API or database
    // For demo purposes, we'll use realistic random variations
    
    // Total Members (base: 1245 ± random variation)
    const membersBase = 1245;
    const membersChange = Math.floor(Math.random() * 20) - 5; // -5 to +15
    const currentMembers = membersBase + membersChange;
    
    // Upcoming Classes (base: 27 ± random variation)
    const classesBase = 27;
    const classesChange = Math.floor(Math.random() * 6) - 2; // -2 to +4
    const currentClasses = classesBase + classesChange;
    
    // Revenue (base: 48750 ± random variation)
    const revenueBase = 48750;
    const revenueChange = Math.floor(Math.random() * 3000) - 500; // -500 to +2500
    const currentRevenue = revenueBase + revenueChange;
    
    // Update the DOM with new values
    document.querySelector('.stats-cards .card:nth-child(1) .number').textContent = formatNumber(currentMembers);
    document.querySelector('.stats-cards .card:nth-child(2) .number').textContent = currentClasses;
    document.querySelector('.stats-cards .card:nth-child(3) .number').textContent = `$${formatNumber(currentRevenue)}`;
    
    // Update the change indicators with realistic trends
    updateChangeIndicator('.stats-cards .card:nth-child(1) .change', membersChange);
    updateChangeIndicator('.stats-cards .card:nth-child(3) .change', revenueChange);
    
    // Update today's classes count
    const todaysClasses = Math.floor(Math.random() * 8) + 1; // 1-8 classes
    document.querySelector('.stats-cards .card:nth-child(2) .change').textContent = 
        `${todaysClasses} today`;
}

function updateChangeIndicator(selector, change) {
    const element = document.querySelector(selector);
    const absChange = Math.abs(change);
    
    if (change > 0) {
        element.textContent = `↑ ${absChange}% this month`;
        element.style.color = '#4CAF50'; // Green for positive
    } else if (change < 0) {
        element.textContent = `↓ ${absChange}% this month`;
        element.style.color = '#ff6b6b'; // Red for negative
    } else {
        element.textContent = `→ No change this month`;
        element.style.color = '#FFC107'; // Yellow for neutral
    }
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function setupSidebarNavigation() {
    const sidebarLinks = document.querySelectorAll('.admin-sidebar a');
    
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all links
            sidebarLinks.forEach(l => l.classList.remove('active'));
            
            // Add active class to clicked link
            this.classList.add('active');
            
            // In a real application, this would load the appropriate content
            // For now, we'll just log to console
            console.log(`Navigating to: ${this.getAttribute('href')}`);
            
            // Show a notification
            showNotification(`Loading ${this.textContent}...`);
        });
    });
}

function showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'admin-notification';
    notification.textContent = message;
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add some basic styling for the notifications
const style = document.createElement('style');
style.textContent = `
.admin-notification {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #4CAF50;
    color: white;
    padding: 15px 25px;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    z-index: 1000;
    opacity: 1;
    transition: opacity 0.3s;
}

.admin-notification.fade-out {
    opacity: 0;
}
`;
document.head.appendChild(style);


// Replace the static product grid with dynamic loading
document.addEventListener('DOMContentLoaded', function() {
  const productGrid = document.querySelector('.product-grid');
  
  // In a real app, you would fetch this from a database
  const products = [
    { name: "Whey Protein", price: 850, image: "whey protein.jpg" },
    { name: "Creatine Monohydrate", price: 450, image: "creatine.avif" },
    { name: "Pre-Workout", price: 600, image: "preworkout.jpg" },
    { name: "BETA ALANINE", price: 500, image: "beta alanine.jpg" },
    { name: "L CARNTINE", price: 300, image: "l carntine.webp" },
    { name: "CARB", price: 550, image: "carb.webp" }
  ];
  
  productGrid.innerHTML = '';
  
  products.forEach(product => {
    const productCard = document.createElement('div');
    productCard.className = 'product-card';
    productCard.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <h3>${product.name}</h3>
      <p>LE ${product.price.toFixed(2)}</p>
      <button class="cart-btn">Add to Cart</button>
    `;
    productGrid.appendChild(productCard);
  });
  
  // Reinitialize cart buttons after loading products
  document.querySelectorAll('.cart-btn').forEach(button => {
    button.addEventListener('click', function() {
      const productCard = this.closest('.product-card');
      const productName = productCard.querySelector('h3').textContent;
      const productPrice = parseFloat(productCard.querySelector('p').textContent.replace('LE ', ''));
      const productImage = productCard.querySelector('img').src;

      addToCart({
        name: productName,
        price: productPrice,
        image: productImage
      });
    });
  });
});
