document.addEventListener('DOMContentLoaded', function() {

    const mockMembers = [
        { id: 1, name: 'Amr', email: 'Amr@example.com', lastLogin: '2023-05-15', hasPaid: true },
        { id: 2, name: 'Sayed', email: 'Sayed@example.com', lastLogin: '2023-05-14', hasPaid: true },
        { id: 3, name: 'Abdallah', email: 'Abdallah@example.com', lastLogin: '2023-05-10', hasPaid: false },
        { id: 4, name: 'Mostafa', email: 'Mostafa@example.com', lastLogin: '2023-05-15', hasPaid: true },
        { id: 4, name: 'george', email: 'george@example.com', lastLogin: '2023-05-15', hasPaid: true },
    ];

    // Calculate stats
    const today = new Date().toISOString().split('T')[0];
    const totalMembers = mockMembers.length;
    const activeToday = mockMembers.filter(member => member.lastLogin === today).length;
    const paidMembers = mockMembers.filter(member => member.hasPaid).length;

    // Update stats
    document.getElementById('totalMembers').textContent = totalMembers;
    document.getElementById('activeToday').textContent = activeToday;
    document.getElementById('paidMembers').textContent = paidMembers;

    // Populate member lists
    const allMembersList = document.getElementById('allMembersList');
    const paidMembersList = document.getElementById('paidMembersList');

    mockMembers.forEach(member => {
        const li = document.createElement('li');
        li.innerHTML = `<strong>${member.name}</strong> (${member.email}) - Last login: ${member.lastLogin}`;
        allMembersList.appendChild(li);

        if (member.hasPaid) {
            const paidLi = document.createElement('li');
            paidLi.innerHTML = `<strong>${member.name}</strong> (${member.email})`;
            paidMembersList.appendChild(paidLi);
        }
    });

    // Search functionality
    const memberSearch = document.getElementById('memberSearch');
    memberSearch.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const members = allMembersList.querySelectorAll('li');
        
        members.forEach(member => {
            const text = member.textContent.toLowerCase();
            member.style.display = text.includes(searchTerm) ? 'block' : 'none';
        });
    });
});


// Admin product management functionality
document.addEventListener('DOMContentLoaded', function() {
    const products = [
      { name: "Whey Protein", price: 850, image: "whey protein.jpg" },
      { name: "Creatine Monohydrate", price: 450, image: "creatine.avif" },
      { name: "Pre-Workout", price: 600, image: "preworkout.jpg" },
      { name: "BETA ALANINE", price: 500, image: "beta alanine.jpg" },
      { name: "L CARNTINE", price: 300, image: "l carntine.webp" },
      { name: "CARB", price: 550, image: "carb.webp" }
    ];
  
    const addProductBtn = document.getElementById('addProductBtn');
    const productModal = document.getElementById('productModal');
    const productForm = document.getElementById('productForm');
    const productsList = document.getElementById('productsList');
    const closeProductModal = productModal.querySelector('.close-btn');
  
    // Display existing products
    function renderProducts() {
      productsList.innerHTML = '';
      products.forEach((product, index) => {
        const productItem = document.createElement('div');
        productItem.className = 'product-item';
        productItem.innerHTML = `
          <div class="product-info">
            <img src="${product.image}" alt="${product.name}" width="50">
            <span>${product.name} - LE ${product.price}</span>
          </div>
          <div class="product-actions">
            <button class="edit-btn" data-index="${index}">Edit</button>
            <button class="delete-btn" data-index="${index}">Delete</button>
          </div>
        `;
        productsList.appendChild(productItem);
      });
  
      // Add event listeners to edit and delete buttons
      document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', function() {
          const index = parseInt(this.dataset.index);
          editProduct(index);
        });
      });
  
      document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
          const index = parseInt(this.dataset.index);
          deleteProduct(index);
        });
      });
    }
  
    // Add new product
    addProductBtn.addEventListener('click', function() {
      productForm.reset();
      productForm.dataset.index = '';
      productModal.style.display = 'block';
    });
  
    // Edit product
    function editProduct(index) {
      const product = products[index];
      document.getElementById('productName').value = product.name;
      document.getElementById('productPrice').value = product.price;
      document.getElementById('productImage').value = product.image;
      productForm.dataset.index = index;
      productModal.style.display = 'block';
    }
  
    // Delete product
    function deleteProduct(index) {
      if (confirm('Are you sure you want to delete this product?')) {
        products.splice(index, 1);
        renderProducts();
        // In a real app, you would also update the database here
      }
    }
  
    // Save product (add or edit)
    productForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const name = document.getElementById('productName').value;
      const price = parseFloat(document.getElementById('productPrice').value);
      const image = document.getElementById('productImage').value;
      
      const index = this.dataset.index;
      
      if (index === '') {
        // Add new product
        products.push({ name, price, image });
      } else {
        // Update existing product
        products[index] = { name, price, image };
      }
      
      renderProducts();
      productModal.style.display = 'none';
      
      // In a real app, you would save to a database here
    });
  
    // Close modal
    closeProductModal.addEventListener('click', function() {
      productModal.style.display = 'none';
    });
  
    window.addEventListener('click', function(event) {
      if (event.target === productModal) {
        productModal.style.display = 'none';
      }
    });
  
    // Initial render
    renderProducts();
  });