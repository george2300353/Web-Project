// Toggle login menu
document.getElementById('userIcon').addEventListener('click', function() {
    var menu = document.getElementById('loginMenu');
    if (menu.style.display === 'none' || menu.style.display === '') {
        menu.style.display = 'block';
    } else {
        menu.style.display = 'none';
    }
});

// Handle login form submission
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Example: Check if username and password are correct
    if (username === "user" && password === "password") {
        alert("Login successful!");
        // Redirect to another page or perform other actions
    } else {
        alert("Invalid username or password.");
    }
});

// Toggle login menu
document.getElementById('userIcon').addEventListener('click', function() {
    var menu = document.getElementById('loginMenu');
    if (menu.style.display === 'none' || menu.style.display === '') {
        menu.style.display = 'block';
    } else {
        menu.style.display = 'none';
    }
});

// Handle login form submission
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Example: Check if username and password are correct
    if (username === "user" && password === "password") {
        alert("Login successful!");
        // Redirect to another page or perform other actions
    } else {
        alert("Invalid username or password.");
    }
});
// Class details data

// Open modal with class details
function openClassModal(className) {
    const modal = document.getElementById("classModal");
    const details = {
        yoga: {
            title: "Yoga",
            image: "yoga-class.jpg",
            description: "Our yoga classes are designed to help you relax, stretch, and strengthen your body. Suitable for all levels, from beginners to advanced practitioners.",
            coach: "Emily Smith",
            schedule: "Monday, Wednesday, Friday at 7:00 AM and 6:00 PM"
        },
        hiit: {
            title: "HIIT",
            image: "hiit-class.jpg",
            description: "High-intensity interval training (HIIT) is perfect for burning fat and improving cardiovascular health. Each session is 45 minutes of intense, calorie-burning workouts.",
            coach: "John Doe",
            schedule: "Tuesday, Thursday at 7:00 AM and 5:00 PM"
        },
        strength: {
            title: "Strength Training",
            image: "strength-class.jpg",
            description: "Build muscle and increase strength with our expert-led strength training sessions. We focus on proper form and technique to maximize results.",
            coach: "Mike Johnson",
            schedule: "Monday, Wednesday, Friday at 8:00 AM and 7:00 PM"
        },
        pilates: {
            title: "Pilates",
            image: "pilates-class.jpg",
            description: "Pilates focuses on core strength, flexibility, and overall body awareness. Suitable for all fitness levels.",
            coach: "Sarah Lee",
            schedule: "Tuesday, Thursday at 9:00 AM and 6:00 PM"
        },
        cycling: {
            title: "Cycling",
            image: "cycling-class.jpg",
            description: "Cardio workout on stationary bikes. Great for improving endurance and burning calories.",
            coach: "Chris Brown",
            schedule: "Monday, Wednesday, Friday at 6:00 AM and 5:00 PM"
        },
        boxing: {
            title: "Boxing",
            image: "boxing-class.jpg",
            description: "Improve agility, strength, and endurance with our boxing classes. No prior experience required.",
            coach: "Alex Green",
            schedule: "Tuesday, Thursday at 8:00 AM and 7:00 PM"
        }
    }[className];

    document.getElementById("modalTitle").textContent = details.title;
    document.getElementById("modalImage").src = details.image;
    document.getElementById("modalDescription").textContent = details.description;
    document.getElementById("modalCoach").textContent = details.coach;
    document.getElementById("modalSchedule").textContent = details.schedule;

    modal.style.display = "block";
}

// Close modal
function closeClassModal() {
    document.getElementById("classModal").style.display = "none";
}
// Class details data
const classDetails = {
    yoga: {
        title: "Yoga",
        image: "yoga-class.jpg",
        description: "Our yoga classes are designed to help you relax, stretch, and strengthen your body. Suitable for all levels, from beginners to advanced practitioners.",
        coach: "Emily Smith",
        schedule: "Monday, Wednesday, Friday at 7:00 AM and 6:00 PM"
    },
    hiit: {
        title: "HIIT",
        image: "hiit-class.jpg",
        description: "High-intensity interval training (HIIT) is perfect for burning fat and improving cardiovascular health. Each session is 45 minutes of intense, calorie-burning workouts.",
        coach: "John Doe",
        schedule: "Tuesday, Thursday at 7:00 AM and 5:00 PM"
    },
    strength: {
        title: "Strength Training",
        image: "strength-class.jpg",
        description: "Build muscle and increase strength with our expert-led strength training sessions. We focus on proper form and technique to maximize results.",
        coach: "Mike Johnson",
        schedule: "Monday, Wednesday, Friday at 8:00 AM and 7:00 PM"
    },
    pilates: {
        title: "Pilates",
        image: "pilates-class.jpg",
        description: "Pilates focuses on core strength, flexibility, and overall body awareness. Suitable for all fitness levels.",
        coach: "Sarah Lee",
        schedule: "Tuesday, Thursday at 9:00 AM and 6:00 PM"
    },
    cycling: {
        title: "Cycling",
        image: "cycling-class.jpg",
        description: "Cardio workout on stationary bikes. Great for improving endurance and burning calories.",
        coach: "Chris Brown",
        schedule: "Monday, Wednesday, Friday at 6:00 AM and 5:00 PM"
    },
    boxing: {
        title: "Boxing",
        image: "boxing-class.jpg",
        description: "Improve agility, strength, and endurance with our boxing classes. No prior experience required.",
        coach: "Alex Green",
        schedule: "Tuesday, Thursday at 8:00 AM and 7:00 PM"
    },
    calisthenics: {
        title: "Calisthenics",
        image: "calisthenics-class.jpg",
        description: "Bodyweight exercises to build strength, flexibility, and endurance. Perfect for functional fitness.",
        coach: "Ryan Clark",
        schedule: "Monday, Wednesday, Friday at 9:00 AM and 6:00 PM"
    },
    crossfit: {
        title: "CrossFit",
        image: "crossfit-class.jpg",
        description: "High-intensity functional training combining weightlifting, cardio, and gymnastics. Push your limits!",
        coach: "Laura White",
        schedule: "Tuesday, Thursday at 7:00 AM and 6:00 PM"
    }
};

// Open modal with class details
function openClassModal(className) {
    const modal = document.getElementById("classModal");
    const details = {
        yoga: {
            title: "Yoga",
            image: "yoga-class.jpg",
            description: "Our yoga classes are designed to help you relax, stretch, and strengthen your body. Suitable for all levels, from beginners to advanced practitioners.",
            coach: "Emily Smith",
            schedule: "Monday, Wednesday, Friday at 7:00 AM and 6:00 PM"
        },
        hiit: {
            title: "HIIT",
            image: "hiit-class.jpg",
            description: "High-intensity interval training (HIIT) is perfect for burning fat and improving cardiovascular health. Each session is 45 minutes of intense, calorie-burning workouts.",
            coach: "John Doe",
            schedule: "Tuesday, Thursday at 7:00 AM and 5:00 PM"
        },
        strength: {
            title: "Strength Training",
            image: "strength-class.jpg",
            description: "Build muscle and increase strength with our expert-led strength training sessions. We focus on proper form and technique to maximize results.",
            coach: "Mike Johnson",
            schedule: "Monday, Wednesday, Friday at 8:00 AM and 7:00 PM"
        },
        pilates: {
            title: "Pilates",
            image: "pilates-class.jpg",
            description: "Pilates focuses on core strength, flexibility, and overall body awareness. Suitable for all fitness levels.",
            coach: "Sarah Lee",
            schedule: "Tuesday, Thursday at 9:00 AM and 6:00 PM"
        },
        cycling: {
            title: "Cycling",
            image: "cycling-class.jpg",
            description: "Cardio workout on stationary bikes. Great for improving endurance and burning calories.",
            coach: "Chris Brown",
            schedule: "Monday, Wednesday, Friday at 6:00 AM and 5:00 PM"
        },
        boxing: {
            title: "Boxing",
            image: "boxing-class.jpg",
            description: "Improve agility, strength, and endurance with our boxing classes. No prior experience required.",
            coach: "Alex Green",
            schedule: "Tuesday, Thursday at 8:00 AM and 7:00 PM"
        }
    }[className];

    document.getElementById("modalTitle").textContent = details.title;
    document.getElementById("modalImage").src = details.image;
    document.getElementById("modalDescription").textContent = details.description;
    document.getElementById("modalCoach").textContent = details.coach;
    document.getElementById("modalSchedule").textContent = details.schedule;

    modal.style.display = "block";
}

// Close modal
function closeClassModal() {
    document.getElementById("classModal").style.display = "none";
}