// Toggle login menu
document.getElementById('userIcon').addEventListener('click', function() {
    var menu = document.getElementById('loginMenu');
    if (menu.style.display === 'none' || menu.style.display === '') {
        menu.style.display = 'block';
    } else {
        menu.style.display = 'none';
    }
});

// Handle login form submission
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Example: Check if username and password are correct
    if (username === "user" && password === "password") {
        alert("Login successful!");
        // Redirect to another page or perform other actions
    } else {
        alert("Invalid username or password.");
    }
});